import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { 
  DollarSign, 
  Shield, 
  FileText, 
  IdCard, 
  Heart, 
  Home,
  Bell,
  Plus,
  AlertTriangle,
  Calendar,
  Search
} from 'lucide-react';
import { cn, formatCurrency, formatDate, getExpirationStatus, getStatusColor } from '@/lib/utils';
import type { 
  FinancialAccount, 
  InsurancePolicy, 
  LegalDocument,
  PersonalId,
  MedicalInfo,
  PropertyAsset,
  Reminder 
} from '@shared/schema';

export function Dashboard() {
  const { data: financialAccounts = [] } = useQuery<FinancialAccount[]>({
    queryKey: ['/api/financial-accounts'],
  });

  const { data: insurancePolicies = [] } = useQuery<InsurancePolicy[]>({
    queryKey: ['/api/insurance-policies'],
  });

  const { data: legalDocuments = [] } = useQuery<LegalDocument[]>({
    queryKey: ['/api/legal-documents'],
  });

  const { data: personalIds = [] } = useQuery<PersonalId[]>({
    queryKey: ['/api/personal-ids'],
  });

  const { data: medicalInfo = [] } = useQuery<MedicalInfo[]>({
    queryKey: ['/api/medical-info'],
  });

  const { data: propertyAssets = [] } = useQuery<PropertyAsset[]>({
    queryKey: ['/api/property-assets'],
  });

  const { data: activeReminders = [] } = useQuery<Reminder[]>({
    queryKey: ['/api/reminders/active'],
  });

  // Calculate summary statistics
  const totalBalance = financialAccounts.reduce((sum, account) => sum + (account.balance || 0), 0);
  const totalCoverage = insurancePolicies.reduce((sum, policy) => sum + policy.coverageAmount, 0);
  const expiringItems = [
    ...insurancePolicies.filter(p => getExpirationStatus(p.renewalDate) === 'expiring'),
    ...personalIds.filter(p => p.expirationDate && getExpirationStatus(p.expirationDate) === 'expiring'),
  ];

  const recentActivity = [
    ...financialAccounts.slice(0, 3).map(acc => ({
      type: 'Financial Account',
      name: acc.accountName,
      date: acc.lastUpdated,
      icon: DollarSign,
    })),
    ...insurancePolicies.slice(0, 3).map(pol => ({
      type: 'Insurance Policy',
      name: `${pol.policyType} - ${pol.provider}`,
      date: pol.lastUpdated,
      icon: Shield,
    })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">
            Your household information command center
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Search className="h-4 w-4 mr-2" />
            Search
          </Button>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>
      </div>

      {/* Alert Banner for Expiring Items */}
      {expiringItems.length > 0 && (
        <Card className="border-yellow-200 dark:border-yellow-800 bg-yellow-50 dark:bg-yellow-900/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
              <span className="font-medium text-yellow-800 dark:text-yellow-200">
                {expiringItems.length} item{expiringItems.length > 1 ? 's' : ''} expiring soon
              </span>
              <Button variant="outline" size="sm" className="ml-auto">
                View Details
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalBalance)}</div>
            <p className="text-xs text-muted-foreground">
              Across {financialAccounts.length} accounts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Insurance Coverage</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalCoverage)}</div>
            <p className="text-xs text-muted-foreground">
              {insurancePolicies.length} active policies
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Documents</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{legalDocuments.length}</div>
            <p className="text-xs text-muted-foreground">
              Legal documents stored
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Reminders</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeReminders.length}</div>
            <p className="text-xs text-muted-foreground">
              Upcoming alerts
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Category Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <CategoryCard
          title="Financial Accounts"
          description="Bank accounts, investments, and financial information"
          icon={DollarSign}
          count={financialAccounts.length}
          href="/financial"
          color="text-green-600 dark:text-green-400"
        />
        
        <CategoryCard
          title="Insurance Policies"
          description="Auto, home, life, and health insurance"
          icon={Shield}
          count={insurancePolicies.length}
          href="/insurance"
          color="text-blue-600 dark:text-blue-400"
        />
        
        <CategoryCard
          title="Legal Documents"
          description="Wills, contracts, and legal paperwork"
          icon={FileText}
          count={legalDocuments.length}
          href="/legal"
          color="text-purple-600 dark:text-purple-400"
        />
        
        <CategoryCard
          title="Personal IDs"
          description="Passports, licenses, and identification"
          icon={IdCard}
          count={personalIds.length}
          href="/personal-ids"
          color="text-orange-600 dark:text-orange-400"
        />
        
        <CategoryCard
          title="Medical Information"
          description="Doctors, prescriptions, and health records"
          icon={Heart}
          count={medicalInfo.length}
          href="/medical"
          color="text-red-600 dark:text-red-400"
        />
        
        <CategoryCard
          title="Property & Assets"
          description="Real estate, vehicles, and valuable items"
          icon={Home}
          count={propertyAssets.length}
          href="/property"
          color="text-indigo-600 dark:text-indigo-400"
        />
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>Recent Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.length > 0 ? (
                recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <activity.icon className="h-4 w-4 text-muted-foreground" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {activity.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {activity.type} • {formatDate(activity.date)}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">
                  No recent activity. Start adding your household information.
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="h-5 w-5" />
              <span>Upcoming Reminders</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeReminders.length > 0 ? (
                activeReminders.slice(0, 5).map((reminder) => (
                  <div key={reminder.id} className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {reminder.title}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(reminder.targetDate)}
                      </p>
                    </div>
                    <span className={cn(
                      "px-2 py-1 text-xs rounded-full font-medium",
                      reminder.category === 'renewal' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' :
                      reminder.category === 'expiration' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
                      'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                    )}>
                      {reminder.category}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">
                  No upcoming reminders. All items are up to date.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

interface CategoryCardProps {
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  count: number;
  href: string;
  color: string;
}

function CategoryCard({ title, description, icon: Icon, count, href, color }: CategoryCardProps) {
  return (
    <Card className="category-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <Icon className={cn("h-8 w-8", color)} />
          <span className="text-2xl font-bold text-muted-foreground">{count}</span>
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">{description}</p>
        <Button variant="outline" size="sm" className="w-full">
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}