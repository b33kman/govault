import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { 
  DollarSign, 
  Plus, 
  Search, 
  Edit,
  Trash2,
  Building2,
  CreditCard,
  TrendingUp,
  PiggyBank
} from 'lucide-react';
import { cn, formatCurrency, formatDate } from '@/lib/utils';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { FinancialAccount } from '@shared/schema';

export function FinancialPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');

  const { data: accounts = [], isLoading } = useQuery<FinancialAccount[]>({
    queryKey: ['/api/financial-accounts'],
  });

  const deleteAccountMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/financial-accounts/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial-accounts'] });
    },
  });

  const filteredAccounts = accounts.filter(account => {
    const matchesSearch = account.accountName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         account.bankName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || account.accountType === selectedType;
    return matchesSearch && matchesType;
  });

  const accountTypeStats = accounts.reduce((stats, account) => {
    const type = account.accountType;
    if (!stats[type]) {
      stats[type] = { count: 0, balance: 0 };
    }
    stats[type].count++;
    stats[type].balance += account.balance || 0;
    return stats;
  }, {} as Record<string, { count: number; balance: number }>);

  const totalBalance = accounts.reduce((sum, account) => sum + (account.balance || 0), 0);

  const getAccountIcon = (type: string) => {
    switch (type) {
      case 'checking':
      case 'savings':
        return PiggyBank;
      case 'credit':
        return CreditCard;
      case 'investment':
        return TrendingUp;
      case 'mortgage':
      case 'loan':
        return Building2;
      default:
        return DollarSign;
    }
  };

  const getAccountTypeColor = (type: string) => {
    switch (type) {
      case 'checking':
        return 'text-blue-600 dark:text-blue-400';
      case 'savings':
        return 'text-green-600 dark:text-green-400';
      case 'credit':
        return 'text-red-600 dark:text-red-400';
      case 'investment':
        return 'text-purple-600 dark:text-purple-400';
      case 'mortgage':
      case 'loan':
        return 'text-orange-600 dark:text-orange-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Financial Accounts</h1>
            <p className="text-muted-foreground">Manage your bank accounts and financial information</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Financial Accounts</h1>
          <p className="text-muted-foreground">
            Manage your bank accounts, investments, and financial information
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Account
        </Button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalBalance)}</div>
            <p className="text-xs text-muted-foreground">
              Across {accounts.length} accounts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Checking & Savings</CardTitle>
            <PiggyBank className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(
                (accountTypeStats.checking?.balance || 0) + (accountTypeStats.savings?.balance || 0)
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {(accountTypeStats.checking?.count || 0) + (accountTypeStats.savings?.count || 0)} accounts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Investments</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(accountTypeStats.investment?.balance || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {accountTypeStats.investment?.count || 0} accounts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Credit & Loans</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(
                (accountTypeStats.credit?.balance || 0) + 
                (accountTypeStats.mortgage?.balance || 0) + 
                (accountTypeStats.loan?.balance || 0)
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {(accountTypeStats.credit?.count || 0) + 
               (accountTypeStats.mortgage?.count || 0) + 
               (accountTypeStats.loan?.count || 0)} accounts
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search accounts or banks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="px-3 py-2 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
        >
          <option value="all">All Types</option>
          <option value="checking">Checking</option>
          <option value="savings">Savings</option>
          <option value="credit">Credit</option>
          <option value="investment">Investment</option>
          <option value="mortgage">Mortgage</option>
          <option value="loan">Loan</option>
        </select>
      </div>

      {/* Accounts Grid */}
      <div className="data-grid">
        {filteredAccounts.length > 0 ? (
          filteredAccounts.map((account) => {
            const IconComponent = getAccountIcon(account.accountType);
            return (
              <Card key={account.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <IconComponent className={cn("h-6 w-6", getAccountTypeColor(account.accountType))} />
                      <div>
                        <CardTitle className="text-lg">{account.accountName}</CardTitle>
                        <p className="text-sm text-muted-foreground capitalize">
                          {account.accountType.replace('_', ' ')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="icon">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => deleteAccountMutation.mutate(account.id)}
                        disabled={deleteAccountMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Bank</p>
                      <p className="font-medium">{account.bankName}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Balance</p>
                      <p className="font-medium text-lg">
                        {account.balance ? formatCurrency(account.balance) : 'N/A'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Account Number</p>
                      <p className="font-mono">***{account.accountNumber.slice(-4)}</p>
                    </div>
                    {account.routingNumber && (
                      <div>
                        <p className="text-muted-foreground">Routing Number</p>
                        <p className="font-mono">{account.routingNumber}</p>
                      </div>
                    )}
                  </div>

                  {account.interestRate && (
                    <div>
                      <p className="text-muted-foreground text-sm">Interest Rate</p>
                      <p className="font-medium">{account.interestRate}%</p>
                    </div>
                  )}

                  {account.contactInfo && (
                    <div>
                      <p className="text-muted-foreground text-sm">Contact</p>
                      <p className="font-medium">{account.contactInfo}</p>
                    </div>
                  )}

                  {account.notes && (
                    <div>
                      <p className="text-muted-foreground text-sm">Notes</p>
                      <p className="text-sm">{account.notes}</p>
                    </div>
                  )}

                  <div className="pt-2 border-t">
                    <p className="text-xs text-muted-foreground">
                      Last updated: {formatDate(account.lastUpdated)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-8 text-center">
                <DollarSign className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Financial Accounts Found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm || selectedType !== 'all' 
                    ? 'No accounts match your current filters.' 
                    : 'Get started by adding your first financial account.'}
                </p>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Financial Account
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}