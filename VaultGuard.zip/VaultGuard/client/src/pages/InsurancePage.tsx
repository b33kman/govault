import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { 
  Shield,
  Plus,
  Search,
  Edit,
  Trash2,
  Car,
  Home,
  Heart,
  Briefcase,
  AlertTriangle,
  Calendar
} from 'lucide-react';
import { cn, formatCurrency, formatDate, getExpirationStatus, getStatusColor, getDaysUntilExpiration } from '@/lib/utils';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { InsurancePolicy } from '@shared/schema';

export function InsurancePage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');

  const { data: policies = [], isLoading } = useQuery<InsurancePolicy[]>({
    queryKey: ['/api/insurance-policies'],
  });

  const deletePolicyMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/insurance-policies/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/insurance-policies'] });
    },
  });

  const filteredPolicies = policies.filter(policy => {
    const matchesSearch = policy.provider.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         policy.policyNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || policy.policyType === selectedType;
    return matchesSearch && matchesType;
  });

  const totalCoverage = policies.reduce((sum, policy) => sum + policy.coverageAmount, 0);
  const totalPremiums = policies.reduce((sum, policy) => sum + policy.premiumAmount, 0);
  
  const expiringPolicies = policies.filter(policy => {
    const status = getExpirationStatus(policy.renewalDate);
    return status === 'expiring' || status === 'expired';
  });

  const getPolicyIcon = (type: string) => {
    switch (type) {
      case 'auto':
        return Car;
      case 'home':
        return Home;
      case 'life':
      case 'health':
        return Heart;
      case 'disability':
      case 'umbrella':
        return Briefcase;
      default:
        return Shield;
    }
  };

  const getPolicyTypeColor = (type: string) => {
    switch (type) {
      case 'auto':
        return 'text-blue-600 dark:text-blue-400';
      case 'home':
        return 'text-green-600 dark:text-green-400';
      case 'life':
        return 'text-red-600 dark:text-red-400';
      case 'health':
        return 'text-purple-600 dark:text-purple-400';
      case 'disability':
        return 'text-orange-600 dark:text-orange-400';
      case 'umbrella':
        return 'text-indigo-600 dark:text-indigo-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Insurance Policies</h1>
            <p className="text-muted-foreground">Manage your insurance coverage and policies</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Insurance Policies</h1>
          <p className="text-muted-foreground">
            Manage your insurance coverage and track renewal dates
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Policy
        </Button>
      </div>

      {/* Alert for Expiring Policies */}
      {expiringPolicies.length > 0 && (
        <Card className="border-yellow-200 dark:border-yellow-800 bg-yellow-50 dark:bg-yellow-900/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
              <span className="font-medium text-yellow-800 dark:text-yellow-200">
                {expiringPolicies.length} policy/policies need attention
              </span>
              <Button variant="outline" size="sm" className="ml-auto">
                Review Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Coverage</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalCoverage)}</div>
            <p className="text-xs text-muted-foreground">
              Across {policies.length} policies
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Annual Premiums</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalPremiums)}</div>
            <p className="text-xs text-muted-foreground">
              Total yearly cost
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Policies</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{policies.length}</div>
            <p className="text-xs text-muted-foreground">
              Currently active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Renewal Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{expiringPolicies.length}</div>
            <p className="text-xs text-muted-foreground">
              Need attention
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search policies or providers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="px-3 py-2 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
        >
          <option value="all">All Types</option>
          <option value="auto">Auto</option>
          <option value="home">Home</option>
          <option value="life">Life</option>
          <option value="health">Health</option>
          <option value="disability">Disability</option>
          <option value="umbrella">Umbrella</option>
        </select>
      </div>

      {/* Policies Grid */}
      <div className="data-grid">
        {filteredPolicies.length > 0 ? (
          filteredPolicies.map((policy) => {
            const IconComponent = getPolicyIcon(policy.policyType);
            const renewalStatus = getExpirationStatus(policy.renewalDate);
            const daysUntilRenewal = getDaysUntilExpiration(policy.renewalDate);
            
            return (
              <Card key={policy.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <IconComponent className={cn("h-6 w-6", getPolicyTypeColor(policy.policyType))} />
                      <div>
                        <CardTitle className="text-lg">{policy.provider}</CardTitle>
                        <p className="text-sm text-muted-foreground capitalize">
                          {policy.policyType} Insurance
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="icon">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => deletePolicyMutation.mutate(policy.id)}
                        disabled={deletePolicyMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Policy Number</p>
                      <p className="font-mono text-sm">{policy.policyNumber}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Coverage</p>
                      <p className="font-medium text-lg">
                        {formatCurrency(policy.coverageAmount)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Premium</p>
                      <p className="font-medium">{formatCurrency(policy.premiumAmount)}</p>
                    </div>
                    {policy.deductible && (
                      <div>
                        <p className="text-muted-foreground">Deductible</p>
                        <p className="font-medium">{formatCurrency(policy.deductible)}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <p className="text-muted-foreground text-sm">Renewal Date</p>
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{formatDate(policy.renewalDate)}</p>
                      <span className={cn(
                        "px-2 py-1 text-xs rounded-full font-medium",
                        renewalStatus === 'expired' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
                        renewalStatus === 'expiring' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
                        'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                      )}>
                        {renewalStatus === 'expired' ? 'Expired' :
                         renewalStatus === 'expiring' ? `${daysUntilRenewal} days` :
                         'Active'}
                      </span>
                    </div>
                  </div>

                  {policy.agentName && (
                    <div>
                      <p className="text-muted-foreground text-sm">Agent</p>
                      <p className="font-medium">{policy.agentName}</p>
                      {policy.agentContact && (
                        <p className="text-sm text-muted-foreground">{policy.agentContact}</p>
                      )}
                    </div>
                  )}

                  {policy.notes && (
                    <div>
                      <p className="text-muted-foreground text-sm">Notes</p>
                      <p className="text-sm">{policy.notes}</p>
                    </div>
                  )}

                  <div className="pt-2 border-t">
                    <p className="text-xs text-muted-foreground">
                      Last updated: {formatDate(policy.lastUpdated)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-8 text-center">
                <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Insurance Policies Found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm || selectedType !== 'all' 
                    ? 'No policies match your current filters.' 
                    : 'Get started by adding your first insurance policy.'}
                </p>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Insurance Policy
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}