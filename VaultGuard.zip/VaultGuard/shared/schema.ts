import { z } from "zod";
import { createInsertSchema } from "drizzle-zod";

// Core data models for GoVAULT household information management

// Financial Accounts
export const financialAccountSchema = z.object({
  id: z.string(),
  accountName: z.string(),
  accountType: z.enum(['checking', 'savings', 'credit', 'investment', 'mortgage', 'loan']),
  accountNumber: z.string(),
  routingNumber: z.string().optional(),
  bankName: z.string(),
  contactInfo: z.string().optional(),
  balance: z.number().optional(),
  interestRate: z.number().optional(),
  documentIds: z.array(z.string()).default([]),
  notes: z.string().optional(),
  lastUpdated: z.date().default(() => new Date()),
});

export const insertFinancialAccountSchema = financialAccountSchema.omit({ id: true, lastUpdated: true });
export type InsertFinancialAccount = z.infer<typeof insertFinancialAccountSchema>;
export type FinancialAccount = z.infer<typeof financialAccountSchema>;

// Insurance Policies
export const insurancePolicySchema = z.object({
  id: z.string(),
  policyType: z.enum(['auto', 'home', 'life', 'health', 'disability', 'umbrella']),
  policyNumber: z.string(),
  provider: z.string(),
  coverageAmount: z.number(),
  deductible: z.number().optional(),
  premiumAmount: z.number(),
  renewalDate: z.date(),
  agentName: z.string().optional(),
  agentContact: z.string().optional(),
  documentIds: z.array(z.string()).default([]),
  notes: z.string().optional(),
  lastUpdated: z.date().default(() => new Date()),
});

export const insertInsurancePolicySchema = insurancePolicySchema.omit({ id: true, lastUpdated: true });
export type InsertInsurancePolicy = z.infer<typeof insertInsurancePolicySchema>;
export type InsurancePolicy = z.infer<typeof insurancePolicySchema>;

// Legal Documents
export const legalDocumentSchema = z.object({
  id: z.string(),
  documentType: z.enum(['will', 'trust', 'power_of_attorney', 'deed', 'contract', 'tax_return', 'other']),
  title: z.string(),
  parties: z.array(z.string()).default([]),
  effectiveDate: z.date().optional(),
  expirationDate: z.date().optional(),
  keyTerms: z.string().optional(),
  documentIds: z.array(z.string()).default([]),
  notes: z.string().optional(),
  lastUpdated: z.date().default(() => new Date()),
});

export const insertLegalDocumentSchema = legalDocumentSchema.omit({ id: true, lastUpdated: true });
export type InsertLegalDocument = z.infer<typeof insertLegalDocumentSchema>;
export type LegalDocument = z.infer<typeof legalDocumentSchema>;

// Personal ID Documents
export const personalIdSchema = z.object({
  id: z.string(),
  idType: z.enum(['passport', 'drivers_license', 'social_security', 'birth_certificate', 'marriage_certificate', 'other']),
  idNumber: z.string(),
  issuingAuthority: z.string(),
  issueDate: z.date().optional(),
  expirationDate: z.date().optional(),
  holderName: z.string(),
  documentIds: z.array(z.string()).default([]),
  notes: z.string().optional(),
  lastUpdated: z.date().default(() => new Date()),
});

export const insertPersonalIdSchema = personalIdSchema.omit({ id: true, lastUpdated: true });
export type InsertPersonalId = z.infer<typeof insertPersonalIdSchema>;
export type PersonalId = z.infer<typeof personalIdSchema>;

// Medical Information
export const medicalInfoSchema = z.object({
  id: z.string(),
  category: z.enum(['doctor', 'pharmacy', 'prescription', 'medical_history', 'emergency_contact', 'other']),
  name: z.string(),
  contactInfo: z.string().optional(),
  details: z.string().optional(),
  insuranceInfo: z.string().optional(),
  documentIds: z.array(z.string()).default([]),
  notes: z.string().optional(),
  lastUpdated: z.date().default(() => new Date()),
});

export const insertMedicalInfoSchema = medicalInfoSchema.omit({ id: true, lastUpdated: true });
export type InsertMedicalInfo = z.infer<typeof insertMedicalInfoSchema>;
export type MedicalInfo = z.infer<typeof medicalInfoSchema>;

// Property Assets
export const propertyAssetSchema = z.object({
  id: z.string(),
  propertyType: z.enum(['primary_residence', 'investment_property', 'vehicle', 'valuable_item', 'other']),
  name: z.string(),
  address: z.string().optional(),
  purchaseDate: z.date().optional(),
  purchasePrice: z.number().optional(),
  currentValue: z.number().optional(),
  mortgageInfo: z.string().optional(),
  insurancePolicyId: z.string().optional(),
  documentIds: z.array(z.string()).default([]),
  notes: z.string().optional(),
  lastUpdated: z.date().default(() => new Date()),
});

export const insertPropertyAssetSchema = propertyAssetSchema.omit({ id: true, lastUpdated: true });
export type InsertPropertyAsset = z.infer<typeof insertPropertyAssetSchema>;
export type PropertyAsset = z.infer<typeof propertyAssetSchema>;

// Documents (for file management)
export const documentSchema = z.object({
  id: z.string(),
  fileName: z.string(),
  fileType: z.string(),
  category: z.enum(['financial', 'insurance', 'legal', 'medical', 'personal_id', 'property']),
  fileSize: z.number(),
  uploadDate: z.date().default(() => new Date()),
  googleDriveFileId: z.string().optional(), // For Google Drive integration
  description: z.string().optional(),
  tags: z.array(z.string()).default([]),
});

export const insertDocumentSchema = documentSchema.omit({ id: true, uploadDate: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = z.infer<typeof documentSchema>;

// User Permissions
export const userPermissionSchema = z.object({
  id: z.string(),
  userEmail: z.string().email(),
  role: z.enum(['owner', 'spouse', 'adult_child', 'dependent', 'financial_advisor', 'attorney', 'tax_preparer']),
  financialView: z.boolean().default(false),
  financialEdit: z.boolean().default(false),
  insuranceView: z.boolean().default(false),
  insuranceEdit: z.boolean().default(false),
  legalView: z.boolean().default(false),
  legalEdit: z.boolean().default(false),
  medicalView: z.boolean().default(false),
  medicalEdit: z.boolean().default(false),
  personalIdView: z.boolean().default(false),
  personalIdEdit: z.boolean().default(false),
  propertyView: z.boolean().default(false),
  propertyEdit: z.boolean().default(false),
  temporaryAccess: z.boolean().default(false),
  accessExpiration: z.date().optional(),
  lastUpdated: z.date().default(() => new Date()),
});

export const insertUserPermissionSchema = userPermissionSchema.omit({ id: true, lastUpdated: true });
export type InsertUserPermission = z.infer<typeof insertUserPermissionSchema>;
export type UserPermission = z.infer<typeof userPermissionSchema>;

// Reminders and Alerts
export const reminderSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  category: z.enum(['renewal', 'expiration', 'payment', 'appointment', 'custom']),
  targetDate: z.date(),
  reminderDays: z.array(z.number()).default([30, 7, 1]), // Days before to remind
  isActive: z.boolean().default(true),
  relatedItemId: z.string().optional(),
  relatedItemType: z.string().optional(),
  createdDate: z.date().default(() => new Date()),
});

export const insertReminderSchema = reminderSchema.omit({ id: true, createdDate: true });
export type InsertReminder = z.infer<typeof insertReminderSchema>;
export type Reminder = z.infer<typeof reminderSchema>;