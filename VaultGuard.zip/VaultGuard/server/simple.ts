import express from 'express';
import path from 'path';

const app = express();
const port = parseInt(process.env.PORT || '3000');

// Middleware
app.use(express.json());
app.use(express.static('dist'));

// Simple API endpoints for testing
app.get('/api/status', (req, res) => {
  res.json({ status: 'GoVAULT server running', timestamp: new Date().toISOString() });
});

app.get('/api/financial-accounts', (req, res) => {
  res.json([
    { id: '1', name: 'Chase Checking', type: 'checking', balance: 15750, institution: 'Chase Bank' },
    { id: '2', name: 'Marcus Savings', type: 'savings', balance: 67500, institution: 'Marcus by Goldman Sachs' },
    { id: '3', name: 'Vanguard Portfolio', type: 'investment', balance: 100000, institution: 'Vanguard' }
  ]);
});

// Handle client-side routing - serve index.html for all non-API routes
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
  }
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log(`GoVAULT server running on port ${port}`);
  console.log(`Dashboard: http://localhost:${port}`);
});