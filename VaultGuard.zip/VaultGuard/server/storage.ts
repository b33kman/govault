import type {
  FinancialAccount,
  InsertFinancialAccount,
  InsurancePolicy,
  InsertInsurancePolicy,
  LegalDocument,
  InsertLegalDocument,
  PersonalId,
  InsertPersonalId,
  MedicalInfo,
  InsertMedicalInfo,
  PropertyAsset,
  InsertPropertyAsset,
  Document,
  InsertDocument,
  UserPermission,
  InsertUserPermission,
  Reminder,
  InsertReminder,
} from "../shared/schema";

export interface IStorage {
  // Financial Accounts
  createFinancialAccount(data: InsertFinancialAccount): Promise<FinancialAccount>;
  getFinancialAccounts(): Promise<FinancialAccount[]>;
  getFinancialAccountById(id: string): Promise<FinancialAccount | null>;
  updateFinancialAccount(id: string, data: Partial<InsertFinancialAccount>): Promise<FinancialAccount>;
  deleteFinancialAccount(id: string): Promise<void>;

  // Insurance Policies
  createInsurancePolicy(data: InsertInsurancePolicy): Promise<InsurancePolicy>;
  getInsurancePolicies(): Promise<InsurancePolicy[]>;
  getInsurancePolicyById(id: string): Promise<InsurancePolicy | null>;
  updateInsurancePolicy(id: string, data: Partial<InsertInsurancePolicy>): Promise<InsurancePolicy>;
  deleteInsurancePolicy(id: string): Promise<void>;

  // Legal Documents
  createLegalDocument(data: InsertLegalDocument): Promise<LegalDocument>;
  getLegalDocuments(): Promise<LegalDocument[]>;
  getLegalDocumentById(id: string): Promise<LegalDocument | null>;
  updateLegalDocument(id: string, data: Partial<InsertLegalDocument>): Promise<LegalDocument>;
  deleteLegalDocument(id: string): Promise<void>;

  // Personal IDs
  createPersonalId(data: InsertPersonalId): Promise<PersonalId>;
  getPersonalIds(): Promise<PersonalId[]>;
  getPersonalIdById(id: string): Promise<PersonalId | null>;
  updatePersonalId(id: string, data: Partial<InsertPersonalId>): Promise<PersonalId>;
  deletePersonalId(id: string): Promise<void>;

  // Medical Information
  createMedicalInfo(data: InsertMedicalInfo): Promise<MedicalInfo>;
  getMedicalInfo(): Promise<MedicalInfo[]>;
  getMedicalInfoById(id: string): Promise<MedicalInfo | null>;
  updateMedicalInfo(id: string, data: Partial<InsertMedicalInfo>): Promise<MedicalInfo>;
  deleteMedicalInfo(id: string): Promise<void>;

  // Property Assets
  createPropertyAsset(data: InsertPropertyAsset): Promise<PropertyAsset>;
  getPropertyAssets(): Promise<PropertyAsset[]>;
  getPropertyAssetById(id: string): Promise<PropertyAsset | null>;
  updatePropertyAsset(id: string, data: Partial<InsertPropertyAsset>): Promise<PropertyAsset>;
  deletePropertyAsset(id: string): Promise<void>;

  // Documents
  createDocument(data: InsertDocument): Promise<Document>;
  getDocuments(): Promise<Document[]>;
  getDocumentById(id: string): Promise<Document | null>;
  getDocumentsByCategory(category: string): Promise<Document[]>;
  updateDocument(id: string, data: Partial<InsertDocument>): Promise<Document>;
  deleteDocument(id: string): Promise<void>;

  // User Permissions
  createUserPermission(data: InsertUserPermission): Promise<UserPermission>;
  getUserPermissions(): Promise<UserPermission[]>;
  getUserPermissionById(id: string): Promise<UserPermission | null>;
  getUserPermissionByEmail(email: string): Promise<UserPermission | null>;
  updateUserPermission(id: string, data: Partial<InsertUserPermission>): Promise<UserPermission>;
  deleteUserPermission(id: string): Promise<void>;

  // Reminders
  createReminder(data: InsertReminder): Promise<Reminder>;
  getReminders(): Promise<Reminder[]>;
  getReminderById(id: string): Promise<Reminder | null>;
  getActiveReminders(): Promise<Reminder[]>;
  updateReminder(id: string, data: Partial<InsertReminder>): Promise<Reminder>;
  deleteReminder(id: string): Promise<void>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private financialAccounts: FinancialAccount[] = [
    {
      id: '1',
      accountName: 'Primary Checking',
      accountType: 'checking',
      accountNumber: '1234567890',
      routingNumber: '021000021',
      bankName: 'Chase Bank',
      contactInfo: '1-800-935-9935',
      balance: 15750.50,
      documentIds: [],
      lastUpdated: new Date('2024-01-15')
    },
    {
      id: '2',
      accountName: 'High Yield Savings',
      accountType: 'savings',
      accountNumber: '9876543210',
      routingNumber: '021000021',
      bankName: 'Marcus by Goldman Sachs',
      contactInfo: '1-855-730-7283',
      balance: 42500.00,
      interestRate: 4.5,
      documentIds: [],
      lastUpdated: new Date('2024-01-10')
    },
    {
      id: '3',
      accountName: 'Investment Portfolio',
      accountType: 'investment',
      accountNumber: '555123789',
      bankName: 'Vanguard',
      contactInfo: '1-877-662-7447',
      balance: 125000.00,
      documentIds: [],
      notes: '401k rollover account',
      lastUpdated: new Date('2024-01-12')
    }
  ];
  
  private insurancePolicies: InsurancePolicy[] = [
    {
      id: '1',
      policyType: 'auto',
      policyNumber: 'AUTO-2024-001',
      provider: 'State Farm',
      coverageAmount: 500000,
      deductible: 1000,
      premiumAmount: 1800,
      renewalDate: new Date('2024-06-15'),
      agentName: 'Sarah Johnson',
      agentContact: '555-123-4567',
      documentIds: [],
      notes: 'Two vehicles covered',
      lastUpdated: new Date('2024-01-05')
    },
    {
      id: '2',
      policyType: 'home',
      policyNumber: 'HOME-2024-002',
      provider: 'Allstate',
      coverageAmount: 750000,
      deductible: 2500,
      premiumAmount: 2400,
      renewalDate: new Date('2024-03-20'),
      agentName: 'Mike Chen',
      agentContact: '555-987-6543',
      documentIds: [],
      lastUpdated: new Date('2024-01-08')
    },
    {
      id: '3',
      policyType: 'life',
      policyNumber: 'LIFE-2024-003',
      provider: 'Northwestern Mutual',
      coverageAmount: 1000000,
      premiumAmount: 3600,
      renewalDate: new Date('2024-12-01'),
      agentName: 'Jennifer Smith',
      agentContact: '555-456-7890',
      documentIds: [],
      notes: 'Term life insurance',
      lastUpdated: new Date('2024-01-03')
    }
  ];
  
  private legalDocuments: LegalDocument[] = [
    {
      id: '1',
      documentType: 'will',
      title: 'Last Will and Testament',
      parties: ['John Smith', 'Jane Smith'],
      effectiveDate: new Date('2023-08-15'),
      documentIds: [],
      notes: 'Updated with new beneficiaries',
      lastUpdated: new Date('2023-08-15')
    },
    {
      id: '2',
      documentType: 'trust',
      title: 'Family Trust Agreement',
      parties: ['Smith Family Trust'],
      effectiveDate: new Date('2023-09-01'),
      documentIds: [],
      keyTerms: 'Revocable living trust',
      lastUpdated: new Date('2023-09-01')
    }
  ];
  
  private personalIds: PersonalId[] = [
    {
      id: '1',
      idType: 'passport',
      idNumber: '123456789',
      issuingAuthority: 'US Department of State',
      issueDate: new Date('2019-06-15'),
      expirationDate: new Date('2029-06-15'),
      holderName: 'John Smith',
      documentIds: [],
      lastUpdated: new Date('2024-01-01')
    },
    {
      id: '2',
      idType: 'drivers_license',
      idNumber: 'D12345678',
      issuingAuthority: 'California DMV',
      issueDate: new Date('2021-03-10'),
      expirationDate: new Date('2026-03-10'),
      holderName: 'John Smith',
      documentIds: [],
      lastUpdated: new Date('2024-01-01')
    }
  ];
  
  private medicalInfo: MedicalInfo[] = [
    {
      id: '1',
      category: 'doctor',
      name: 'Dr. Emily Rodriguez',
      contactInfo: '555-123-9876 - Family Medicine',
      details: 'Primary care physician',
      insuranceInfo: 'Accepts Blue Cross Blue Shield',
      documentIds: [],
      lastUpdated: new Date('2024-01-05')
    },
    {
      id: '2',
      category: 'pharmacy',
      name: 'CVS Pharmacy',
      contactInfo: '555-456-1234 - Main Street Location',
      details: 'Primary pharmacy for prescriptions',
      documentIds: [],
      lastUpdated: new Date('2024-01-07')
    }
  ];
  
  private propertyAssets: PropertyAsset[] = [
    {
      id: '1',
      propertyType: 'primary_residence',
      name: 'Family Home',
      address: '123 Oak Street, Springfield, CA 94105',
      purchaseDate: new Date('2018-05-15'),
      purchasePrice: 650000,
      currentValue: 780000,
      mortgageInfo: 'Wells Fargo - 30yr fixed at 3.25%',
      insurancePolicyId: '2',
      documentIds: [],
      lastUpdated: new Date('2024-01-01')
    },
    {
      id: '2',
      propertyType: 'vehicle',
      name: '2022 Honda Accord',
      purchaseDate: new Date('2022-03-01'),
      purchasePrice: 32000,
      currentValue: 28000,
      insurancePolicyId: '1',
      documentIds: [],
      notes: 'Primary family vehicle',
      lastUpdated: new Date('2024-01-01')
    }
  ];
  
  private documents: Document[] = [];
  private userPermissions: UserPermission[] = [];
  private reminders: Reminder[] = [
    {
      id: '1',
      title: 'Home Insurance Renewal',
      description: 'Allstate policy renewal due',
      category: 'renewal',
      targetDate: new Date('2024-03-20'),
      reminderDays: [30, 7, 1],
      isActive: true,
      relatedItemId: '2',
      relatedItemType: 'insurance',
      createdDate: new Date('2024-01-01')
    },
    {
      id: '2',
      title: 'Auto Insurance Renewal',
      description: 'State Farm policy renewal due',
      category: 'renewal',
      targetDate: new Date('2024-06-15'),
      reminderDays: [30, 7, 1],
      isActive: true,
      relatedItemId: '1',
      relatedItemType: 'insurance',
      createdDate: new Date('2024-01-01')
    }
  ];

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  // Financial Accounts
  async createFinancialAccount(data: InsertFinancialAccount): Promise<FinancialAccount> {
    const account: FinancialAccount = {
      ...data,
      id: this.generateId(),
      lastUpdated: new Date(),
    };
    this.financialAccounts.push(account);
    return account;
  }

  async getFinancialAccounts(): Promise<FinancialAccount[]> {
    return this.financialAccounts;
  }

  async getFinancialAccountById(id: string): Promise<FinancialAccount | null> {
    return this.financialAccounts.find(account => account.id === id) || null;
  }

  async updateFinancialAccount(id: string, data: Partial<InsertFinancialAccount>): Promise<FinancialAccount> {
    const index = this.financialAccounts.findIndex(account => account.id === id);
    if (index === -1) throw new Error('Financial account not found');
    
    this.financialAccounts[index] = {
      ...this.financialAccounts[index],
      ...data,
      lastUpdated: new Date(),
    };
    return this.financialAccounts[index];
  }

  async deleteFinancialAccount(id: string): Promise<void> {
    this.financialAccounts = this.financialAccounts.filter(account => account.id !== id);
  }

  // Insurance Policies
  async createInsurancePolicy(data: InsertInsurancePolicy): Promise<InsurancePolicy> {
    const policy: InsurancePolicy = {
      ...data,
      id: this.generateId(),
      lastUpdated: new Date(),
    };
    this.insurancePolicies.push(policy);
    return policy;
  }

  async getInsurancePolicies(): Promise<InsurancePolicy[]> {
    return this.insurancePolicies;
  }

  async getInsurancePolicyById(id: string): Promise<InsurancePolicy | null> {
    return this.insurancePolicies.find(policy => policy.id === id) || null;
  }

  async updateInsurancePolicy(id: string, data: Partial<InsertInsurancePolicy>): Promise<InsurancePolicy> {
    const index = this.insurancePolicies.findIndex(policy => policy.id === id);
    if (index === -1) throw new Error('Insurance policy not found');
    
    this.insurancePolicies[index] = {
      ...this.insurancePolicies[index],
      ...data,
      lastUpdated: new Date(),
    };
    return this.insurancePolicies[index];
  }

  async deleteInsurancePolicy(id: string): Promise<void> {
    this.insurancePolicies = this.insurancePolicies.filter(policy => policy.id !== id);
  }

  // Legal Documents
  async createLegalDocument(data: InsertLegalDocument): Promise<LegalDocument> {
    const document: LegalDocument = {
      ...data,
      id: this.generateId(),
      lastUpdated: new Date(),
    };
    this.legalDocuments.push(document);
    return document;
  }

  async getLegalDocuments(): Promise<LegalDocument[]> {
    return this.legalDocuments;
  }

  async getLegalDocumentById(id: string): Promise<LegalDocument | null> {
    return this.legalDocuments.find(doc => doc.id === id) || null;
  }

  async updateLegalDocument(id: string, data: Partial<InsertLegalDocument>): Promise<LegalDocument> {
    const index = this.legalDocuments.findIndex(doc => doc.id === id);
    if (index === -1) throw new Error('Legal document not found');
    
    this.legalDocuments[index] = {
      ...this.legalDocuments[index],
      ...data,
      lastUpdated: new Date(),
    };
    return this.legalDocuments[index];
  }

  async deleteLegalDocument(id: string): Promise<void> {
    this.legalDocuments = this.legalDocuments.filter(doc => doc.id !== id);
  }

  // Personal IDs
  async createPersonalId(data: InsertPersonalId): Promise<PersonalId> {
    const personalId: PersonalId = {
      ...data,
      id: this.generateId(),
      lastUpdated: new Date(),
    };
    this.personalIds.push(personalId);
    return personalId;
  }

  async getPersonalIds(): Promise<PersonalId[]> {
    return this.personalIds;
  }

  async getPersonalIdById(id: string): Promise<PersonalId | null> {
    return this.personalIds.find(pid => pid.id === id) || null;
  }

  async updatePersonalId(id: string, data: Partial<InsertPersonalId>): Promise<PersonalId> {
    const index = this.personalIds.findIndex(pid => pid.id === id);
    if (index === -1) throw new Error('Personal ID not found');
    
    this.personalIds[index] = {
      ...this.personalIds[index],
      ...data,
      lastUpdated: new Date(),
    };
    return this.personalIds[index];
  }

  async deletePersonalId(id: string): Promise<void> {
    this.personalIds = this.personalIds.filter(pid => pid.id !== id);
  }

  // Medical Information
  async createMedicalInfo(data: InsertMedicalInfo): Promise<MedicalInfo> {
    const medInfo: MedicalInfo = {
      ...data,
      id: this.generateId(),
      lastUpdated: new Date(),
    };
    this.medicalInfo.push(medInfo);
    return medInfo;
  }

  async getMedicalInfo(): Promise<MedicalInfo[]> {
    return this.medicalInfo;
  }

  async getMedicalInfoById(id: string): Promise<MedicalInfo | null> {
    return this.medicalInfo.find(info => info.id === id) || null;
  }

  async updateMedicalInfo(id: string, data: Partial<InsertMedicalInfo>): Promise<MedicalInfo> {
    const index = this.medicalInfo.findIndex(info => info.id === id);
    if (index === -1) throw new Error('Medical information not found');
    
    this.medicalInfo[index] = {
      ...this.medicalInfo[index],
      ...data,
      lastUpdated: new Date(),
    };
    return this.medicalInfo[index];
  }

  async deleteMedicalInfo(id: string): Promise<void> {
    this.medicalInfo = this.medicalInfo.filter(info => info.id !== id);
  }

  // Property Assets
  async createPropertyAsset(data: InsertPropertyAsset): Promise<PropertyAsset> {
    const asset: PropertyAsset = {
      ...data,
      id: this.generateId(),
      lastUpdated: new Date(),
    };
    this.propertyAssets.push(asset);
    return asset;
  }

  async getPropertyAssets(): Promise<PropertyAsset[]> {
    return this.propertyAssets;
  }

  async getPropertyAssetById(id: string): Promise<PropertyAsset | null> {
    return this.propertyAssets.find(asset => asset.id === id) || null;
  }

  async updatePropertyAsset(id: string, data: Partial<InsertPropertyAsset>): Promise<PropertyAsset> {
    const index = this.propertyAssets.findIndex(asset => asset.id === id);
    if (index === -1) throw new Error('Property asset not found');
    
    this.propertyAssets[index] = {
      ...this.propertyAssets[index],
      ...data,
      lastUpdated: new Date(),
    };
    return this.propertyAssets[index];
  }

  async deletePropertyAsset(id: string): Promise<void> {
    this.propertyAssets = this.propertyAssets.filter(asset => asset.id !== id);
  }

  // Documents
  async createDocument(data: InsertDocument): Promise<Document> {
    const document: Document = {
      ...data,
      id: this.generateId(),
      uploadDate: new Date(),
    };
    this.documents.push(document);
    return document;
  }

  async getDocuments(): Promise<Document[]> {
    return this.documents;
  }

  async getDocumentById(id: string): Promise<Document | null> {
    return this.documents.find(doc => doc.id === id) || null;
  }

  async getDocumentsByCategory(category: string): Promise<Document[]> {
    return this.documents.filter(doc => doc.category === category);
  }

  async updateDocument(id: string, data: Partial<InsertDocument>): Promise<Document> {
    const index = this.documents.findIndex(doc => doc.id === id);
    if (index === -1) throw new Error('Document not found');
    
    this.documents[index] = {
      ...this.documents[index],
      ...data,
    };
    return this.documents[index];
  }

  async deleteDocument(id: string): Promise<void> {
    this.documents = this.documents.filter(doc => doc.id !== id);
  }

  // User Permissions
  async createUserPermission(data: InsertUserPermission): Promise<UserPermission> {
    const permission: UserPermission = {
      ...data,
      id: this.generateId(),
      lastUpdated: new Date(),
    };
    this.userPermissions.push(permission);
    return permission;
  }

  async getUserPermissions(): Promise<UserPermission[]> {
    return this.userPermissions;
  }

  async getUserPermissionById(id: string): Promise<UserPermission | null> {
    return this.userPermissions.find(perm => perm.id === id) || null;
  }

  async getUserPermissionByEmail(email: string): Promise<UserPermission | null> {
    return this.userPermissions.find(perm => perm.userEmail === email) || null;
  }

  async updateUserPermission(id: string, data: Partial<InsertUserPermission>): Promise<UserPermission> {
    const index = this.userPermissions.findIndex(perm => perm.id === id);
    if (index === -1) throw new Error('User permission not found');
    
    this.userPermissions[index] = {
      ...this.userPermissions[index],
      ...data,
      lastUpdated: new Date(),
    };
    return this.userPermissions[index];
  }

  async deleteUserPermission(id: string): Promise<void> {
    this.userPermissions = this.userPermissions.filter(perm => perm.id !== id);
  }

  // Reminders
  async createReminder(data: InsertReminder): Promise<Reminder> {
    const reminder: Reminder = {
      ...data,
      id: this.generateId(),
      createdDate: new Date(),
    };
    this.reminders.push(reminder);
    return reminder;
  }

  async getReminders(): Promise<Reminder[]> {
    return this.reminders;
  }

  async getReminderById(id: string): Promise<Reminder | null> {
    return this.reminders.find(reminder => reminder.id === id) || null;
  }

  async getActiveReminders(): Promise<Reminder[]> {
    return this.reminders.filter(reminder => reminder.isActive);
  }

  async updateReminder(id: string, data: Partial<InsertReminder>): Promise<Reminder> {
    const index = this.reminders.findIndex(reminder => reminder.id === id);
    if (index === -1) throw new Error('Reminder not found');
    
    this.reminders[index] = {
      ...this.reminders[index],
      ...data,
    };
    return this.reminders[index];
  }

  async deleteReminder(id: string): Promise<void> {
    this.reminders = this.reminders.filter(reminder => reminder.id !== id);
  }
}