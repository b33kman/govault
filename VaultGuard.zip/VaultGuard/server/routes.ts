import express from 'express';
import { IStorage } from './storage';
import {
  insertFinancialAccountSchema,
  insertInsurancePolicySchema,
  insertLegalDocumentSchema,
  insertPersonalIdSchema,
  insertMedicalInfoSchema,
  insertPropertyAssetSchema,
  insertDocumentSchema,
  insertUserPermissionSchema,
  insertReminderSchema,
} from '../shared/schema';

export function createRoutes(storage: IStorage) {
  const router = express.Router();

  // Financial Accounts
  router.get('/api/financial-accounts', async (req, res) => {
    try {
      const accounts = await storage.getFinancialAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch financial accounts' });
    }
  });

  router.post('/api/financial-accounts', async (req, res) => {
    try {
      const data = insertFinancialAccountSchema.parse(req.body);
      const account = await storage.createFinancialAccount(data);
      res.json(account);
    } catch (error) {
      res.status(400).json({ error: 'Invalid financial account data' });
    }
  });

  router.put('/api/financial-accounts/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertFinancialAccountSchema.partial().parse(req.body);
      const account = await storage.updateFinancialAccount(id, data);
      res.json(account);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update financial account' });
    }
  });

  router.delete('/api/financial-accounts/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteFinancialAccount(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: 'Failed to delete financial account' });
    }
  });

  // Insurance Policies
  router.get('/api/insurance-policies', async (req, res) => {
    try {
      const policies = await storage.getInsurancePolicies();
      res.json(policies);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch insurance policies' });
    }
  });

  router.post('/api/insurance-policies', async (req, res) => {
    try {
      const data = insertInsurancePolicySchema.parse(req.body);
      const policy = await storage.createInsurancePolicy(data);
      res.json(policy);
    } catch (error) {
      res.status(400).json({ error: 'Invalid insurance policy data' });
    }
  });

  router.put('/api/insurance-policies/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertInsurancePolicySchema.partial().parse(req.body);
      const policy = await storage.updateInsurancePolicy(id, data);
      res.json(policy);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update insurance policy' });
    }
  });

  router.delete('/api/insurance-policies/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteInsurancePolicy(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: 'Failed to delete insurance policy' });
    }
  });

  // Legal Documents
  router.get('/api/legal-documents', async (req, res) => {
    try {
      const documents = await storage.getLegalDocuments();
      res.json(documents);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch legal documents' });
    }
  });

  router.post('/api/legal-documents', async (req, res) => {
    try {
      const data = insertLegalDocumentSchema.parse(req.body);
      const document = await storage.createLegalDocument(data);
      res.json(document);
    } catch (error) {
      res.status(400).json({ error: 'Invalid legal document data' });
    }
  });

  router.put('/api/legal-documents/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertLegalDocumentSchema.partial().parse(req.body);
      const document = await storage.updateLegalDocument(id, data);
      res.json(document);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update legal document' });
    }
  });

  router.delete('/api/legal-documents/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteLegalDocument(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: 'Failed to delete legal document' });
    }
  });

  // Personal IDs
  router.get('/api/personal-ids', async (req, res) => {
    try {
      const personalIds = await storage.getPersonalIds();
      res.json(personalIds);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch personal IDs' });
    }
  });

  router.post('/api/personal-ids', async (req, res) => {
    try {
      const data = insertPersonalIdSchema.parse(req.body);
      const personalId = await storage.createPersonalId(data);
      res.json(personalId);
    } catch (error) {
      res.status(400).json({ error: 'Invalid personal ID data' });
    }
  });

  router.put('/api/personal-ids/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertPersonalIdSchema.partial().parse(req.body);
      const personalId = await storage.updatePersonalId(id, data);
      res.json(personalId);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update personal ID' });
    }
  });

  router.delete('/api/personal-ids/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deletePersonalId(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: 'Failed to delete personal ID' });
    }
  });

  // Medical Information
  router.get('/api/medical-info', async (req, res) => {
    try {
      const medicalInfo = await storage.getMedicalInfo();
      res.json(medicalInfo);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch medical information' });
    }
  });

  router.post('/api/medical-info', async (req, res) => {
    try {
      const data = insertMedicalInfoSchema.parse(req.body);
      const medicalInfo = await storage.createMedicalInfo(data);
      res.json(medicalInfo);
    } catch (error) {
      res.status(400).json({ error: 'Invalid medical information data' });
    }
  });

  router.put('/api/medical-info/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertMedicalInfoSchema.partial().parse(req.body);
      const medicalInfo = await storage.updateMedicalInfo(id, data);
      res.json(medicalInfo);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update medical information' });
    }
  });

  router.delete('/api/medical-info/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteMedicalInfo(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: 'Failed to delete medical information' });
    }
  });

  // Property Assets
  router.get('/api/property-assets', async (req, res) => {
    try {
      const assets = await storage.getPropertyAssets();
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch property assets' });
    }
  });

  router.post('/api/property-assets', async (req, res) => {
    try {
      const data = insertPropertyAssetSchema.parse(req.body);
      const asset = await storage.createPropertyAsset(data);
      res.json(asset);
    } catch (error) {
      res.status(400).json({ error: 'Invalid property asset data' });
    }
  });

  router.put('/api/property-assets/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertPropertyAssetSchema.partial().parse(req.body);
      const asset = await storage.updatePropertyAsset(id, data);
      res.json(asset);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update property asset' });
    }
  });

  router.delete('/api/property-assets/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deletePropertyAsset(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: 'Failed to delete property asset' });
    }
  });

  // Documents
  router.get('/api/documents', async (req, res) => {
    try {
      const documents = await storage.getDocuments();
      res.json(documents);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch documents' });
    }
  });

  router.get('/api/documents/category/:category', async (req, res) => {
    try {
      const { category } = req.params;
      const documents = await storage.getDocumentsByCategory(category);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch documents by category' });
    }
  });

  router.post('/api/documents', async (req, res) => {
    try {
      const data = insertDocumentSchema.parse(req.body);
      const document = await storage.createDocument(data);
      res.json(document);
    } catch (error) {
      res.status(400).json({ error: 'Invalid document data' });
    }
  });

  // Reminders
  router.get('/api/reminders', async (req, res) => {
    try {
      const reminders = await storage.getReminders();
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch reminders' });
    }
  });

  router.get('/api/reminders/active', async (req, res) => {
    try {
      const reminders = await storage.getActiveReminders();
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch active reminders' });
    }
  });

  router.post('/api/reminders', async (req, res) => {
    try {
      const data = insertReminderSchema.parse(req.body);
      const reminder = await storage.createReminder(data);
      res.json(reminder);
    } catch (error) {
      res.status(400).json({ error: 'Invalid reminder data' });
    }
  });

  return router;
}