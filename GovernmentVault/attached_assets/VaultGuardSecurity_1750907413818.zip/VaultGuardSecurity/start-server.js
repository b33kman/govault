#!/usr/bin/env node
const { spawn } = require('child_process');

const server = spawn('node', ['run.js'], {
  stdio: 'inherit',
  env: { ...process.env, PORT: '3000' }
});

server.on('close', (code) => {
  console.log(`Server process exited with code ${code}`);
});

process.on('SIGINT', () => {
  server.kill('SIGINT');
  process.exit(0);
});