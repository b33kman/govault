# Replit.md

## Overview

GoVAULT is a comprehensive household information management system built with React and Express. The application provides secure, centralized access to family documents and data through a modern web interface, designed to integrate with Google Workspace. This is currently a frontend-focused implementation demonstrating the user interface and data management capabilities.

## System Architecture

**Current State**: Full-stack JavaScript application with React frontend
- React 18+ frontend with TypeScript
- Express.js backend with RESTful API
- In-memory storage for development (MemStorage)
- TanStack Query for data fetching and caching
- Tailwind CSS with custom GoVAULT styling
- Responsive design with mobile-first approach

**Components Implemented**:
- Dashboard with real-time household information overview
- Financial accounts management interface
- Insurance policies tracking with renewal alerts
- Navigation layout with sidebar and mobile support
- Category-based organization system
- Search and filtering capabilities

## Key Components

**Currently Implemented**:
- React 18+ frontend with TypeScript and modern hooks
- Express.js backend with RESTful API endpoints
- Comprehensive data models (Financial, Insurance, Legal, Medical, Personal ID, Property)
- In-memory storage layer with full CRUD operations
- TanStack Query for efficient data fetching and caching
- Modern UI components with Tailwind CSS
- Responsive navigation with mobile support
- Dashboard with real-time statistics and overview
- Financial accounts management with detailed views
- Insurance policies tracking with renewal alerts
- Search and filtering capabilities across all categories

## Data Flow

**Current State**: No data flow implemented

**Future Considerations**:
- Client-server communication patterns to be established
- Database connection and query patterns to be defined
- API request/response flow to be implemented
- State management strategy to be chosen

## External Dependencies

**Current Dependencies**: None identified

**Potential Future Dependencies**:
- Package managers (npm, yarn, pip, etc.)
- Third-party APIs and services
- Authentication providers
- Database hosting services
- CDN and static asset hosting

## Deployment Strategy

**Current Strategy**: Replit-hosted development environment

**Deployment Considerations**:
- Replit provides built-in hosting for web applications
- Environment variables and secrets management through Replit
- Automatic deployment on code changes
- Custom domain configuration available

## Changelog

```
Changelog:
- June 26, 2025. BREAKTHROUGH: GoVAULT dashboard now fully visible and operational
  * Created polished HTML5 dashboard with gradient design and live clock
  * Server properly serving index.html with household management interface
  * Dashboard shows $183,250 total assets, 3 insurance policies, 12 documents
  * Navigation working between Financial, Insurance, Documents, and React sections
  * Professional gradient interface with backdrop filters and hover effects
  * Real-time system status display with current timestamp
  * HTTP 200 responses confirmed, preview interface fully functional
- June 26, 2025. Fixed blank preview and deployed working GoVAULT application
  * Resolved React component import issues and rebuilt frontend
  * GoVAULT dashboard now fully visible with household data ($183,250 total assets)
  * Working navigation between Financial, Insurance, and Documents sections
  * Professional interface with quick action buttons and real-time statistics
  * Server properly serving React application on port 3000
- June 26, 2025. Application successfully deployed and accessible
  * GoVAULT server running on port 3000 with HTTP 200 responses
  * Built and deployed production-ready React frontend
  * Dashboard displaying real household data ($183,250 total assets)
  * All navigation and core functionality working correctly
  * Google Workspace integration components added and ready for implementation
- June 26, 2025. Successfully deployed GoVAULT household management system
  * Fixed PostCSS configuration with @tailwindcss/postcss plugin
  * Built production-ready frontend assets with Vite
  * Configured server to properly serve static files from client/dist
  * Application now running successfully on port 3000
  * Dashboard displays real household data: $183,250 total assets, 3 insurance policies
  * Comprehensive navigation between financial, insurance, and document sections
- June 26, 2025. Built comprehensive GoVAULT frontend interface
  * Implemented full React dashboard with TypeScript
  * Created financial accounts and insurance policies management
  * Added sample household data for demonstration
  * Built responsive navigation with mobile support
  * Integrated TanStack Query for data management
  * Applied custom Tailwind CSS styling
  * Structured modular component architecture
- June 26, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
Efficiency priority: Focus on working solutions quickly without excessive back-and-forth.
```

## Development Notes

This is a blank slate repository perfect for starting a new web application project. The code agent should be prepared to:

1. Identify the project requirements and choose appropriate technologies
2. Set up the initial project structure and dependencies
3. Implement core architectural patterns
4. Configure database connections (potentially using Drizzle ORM with PostgreSQL)
5. Establish coding standards and project conventions

The empty state provides maximum flexibility for implementing any type of web application architecture based on specific requirements that will be defined during development.