import { useState } from 'react';
import { Router, Route } from 'wouter';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Create a working dashboard component
function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">GoVAULT Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-700">Total Assets</h3>
            <p className="text-3xl font-bold text-green-600">$183,250</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-700">Insurance Policies</h3>
            <p className="text-3xl font-bold text-blue-600">3</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-700">Documents</h3>
            <p className="text-3xl font-bold text-purple-600">12</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Financial Accounts</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Main Checking</span>
                <span className="font-semibold">$12,450</span>
              </div>
              <div className="flex justify-between">
                <span>Savings Account</span>
                <span className="font-semibold">$45,800</span>
              </div>
              <div className="flex justify-between">
                <span>Investment Portfolio</span>
                <span className="font-semibold">$125,000</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Insurance Policies</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Home Insurance</span>
                <span className="text-green-600">Active</span>
              </div>
              <div className="flex justify-between">
                <span>Auto Insurance</span>
                <span className="text-green-600">Active</span>
              </div>
              <div className="flex justify-between">
                <span>Life Insurance</span>
                <span className="text-yellow-600">Renewal Due</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button className="p-4 bg-blue-500 text-white rounded hover:bg-blue-600">
              Add Document
            </button>
            <button className="p-4 bg-green-500 text-white rounded hover:bg-green-600">
              Update Account
            </button>
            <button className="p-4 bg-purple-500 text-white rounded hover:bg-purple-600">
              Set Reminder
            </button>
            <button className="p-4 bg-orange-500 text-white rounded hover:bg-orange-600">
              Generate Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Navigation component
function Navigation() {
  return (
    <nav className="bg-blue-600 text-white p-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <h1 className="text-xl font-bold">GoVAULT</h1>
        <div className="space-x-4">
          <a href="/" className="hover:text-blue-200">Dashboard</a>
          <a href="/financial" className="hover:text-blue-200">Financial</a>
          <a href="/insurance" className="hover:text-blue-200">Insurance</a>
          <a href="/documents" className="hover:text-blue-200">Documents</a>
        </div>
      </div>
    </nav>
  );
}

// Simple financial page
function FinancialPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <div className="max-w-7xl mx-auto py-6 px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Financial Accounts</h1>
        <div className="bg-white p-6 rounded-lg shadow">
          <p>Financial account management interface will be implemented here.</p>
        </div>
      </div>
    </div>
  );
}

// Simple insurance page
function InsurancePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <div className="max-w-7xl mx-auto py-6 px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Insurance Policies</h1>
        <div className="bg-white p-6 rounded-lg shadow">
          <p>Insurance policy management interface will be implemented here.</p>
        </div>
      </div>
    </div>
  );
}

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div>
          <Navigation />
          <Route path="/" component={Dashboard} />
          <Route path="/financial" component={FinancialPage} />
          <Route path="/insurance" component={InsurancePage} />
          <Route path="/documents">
            <div className="min-h-screen bg-gray-50">
              <div className="max-w-7xl mx-auto py-6 px-4">
                <h1 className="text-3xl font-bold text-gray-900 mb-6">Documents</h1>
                <div className="bg-white p-6 rounded-lg shadow">
                  <p>Document management interface will be implemented here.</p>
                </div>
              </div>
            </div>
          </Route>
        </div>
      </Router>
    </QueryClientProvider>
  );
}