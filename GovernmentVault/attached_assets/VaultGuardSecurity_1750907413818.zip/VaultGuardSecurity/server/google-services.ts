import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';
import type {
  FinancialAccount,
  InsurancePolicy,
  LegalDocument,
  PersonalId,
  MedicalInfo,
  PropertyAsset,
  Document,
  UserPermission,
  Reminder,
} from '../shared/schema';

// Google Workspace service integration
export class GoogleWorkspaceService {
  private auth: OAuth2Client;
  private drive: any;
  private sheets: any;
  private docs: any;
  private gmail: any;

  constructor() {
    this.auth = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      process.env.GOOGLE_REDIRECT_URI
    );

    this.drive = google.drive({ version: 'v3', auth: this.auth });
    this.sheets = google.sheets({ version: 'v4', auth: this.auth });
    this.docs = google.docs({ version: 'v1', auth: this.auth });
    this.gmail = google.gmail({ version: 'v1', auth: this.auth });
  }

  setCredentials(tokens: any) {
    this.auth.setCredentials(tokens);
  }

  // Drive folder structure management
  async initializeFolderStructure(): Promise<string> {
    const folders = [
      'GoVAULT_Family_Data',
      'GoVAULT_Family_Data/Documents',
      'GoVAULT_Family_Data/Documents/Financial',
      'GoVAULT_Family_Data/Documents/Insurance',
      'GoVAULT_Family_Data/Documents/Legal',
      'GoVAULT_Family_Data/Documents/Medical',
      'GoVAULT_Family_Data/Documents/Personal_ID',
      'GoVAULT_Family_Data/Documents/Property',
      'GoVAULT_Family_Data/Generated_Reports',
      'GoVAULT_Family_Data/System_Backups',
    ];

    let parentId = 'root';
    const folderMap = new Map<string, string>();

    for (const folderPath of folders) {
      const folderName = folderPath.split('/').pop() || '';
      const parentPath = folderPath.substring(0, folderPath.lastIndexOf('/'));
      
      const currentParentId = parentPath ? folderMap.get(parentPath) || parentId : parentId;

      try {
        // Check if folder exists
        const existingFolders = await this.drive.files.list({
          q: `name='${folderName}' and parents in '${currentParentId}' and mimeType='application/vnd.google-apps.folder'`,
        });

        let folderId;
        if (existingFolders.data.files.length === 0) {
          // Create folder
          const folder = await this.drive.files.create({
            resource: {
              name: folderName,
              mimeType: 'application/vnd.google-apps.folder',
              parents: [currentParentId],
            },
          });
          folderId = folder.data.id;
        } else {
          folderId = existingFolders.data.files[0].id;
        }

        folderMap.set(folderPath, folderId);
        if (folderPath === 'GoVAULT_Family_Data') {
          parentId = folderId;
        }
      } catch (error) {
        console.error(`Error creating folder ${folderPath}:`, error);
        throw error;
      }
    }

    return folderMap.get('GoVAULT_Family_Data') || '';
  }

  // Google Sheets data management
  async initializeDataSheets(folderId: string): Promise<Record<string, string>> {
    const sheets = [
      'Financial_Accounts',
      'Insurance_Policies',
      'Legal_Documents',
      'Personal_ID',
      'Medical_Info',
      'Property_Assets',
      'Users_Permissions',
      'Audit_Log',
      'Document_Registry',
      'Reminders_Alerts',
      'System_Config',
    ];

    const sheetIds: Record<string, string> = {};

    for (const sheetName of sheets) {
      try {
        // Check if sheet exists
        const existingSheets = await this.drive.files.list({
          q: `name='${sheetName}' and parents in '${folderId}' and mimeType='application/vnd.google-apps.spreadsheet'`,
        });

        let sheetId;
        if (existingSheets.data.files.length === 0) {
          // Create new sheet
          const sheet = await this.sheets.spreadsheets.create({
            resource: {
              properties: {
                title: sheetName,
              },
            },
          });

          sheetId = sheet.data.spreadsheetId;

          // Move to correct folder
          await this.drive.files.update({
            fileId: sheetId,
            addParents: folderId,
            removeParents: 'root',
          });

          // Initialize headers based on sheet type
          await this.initializeSheetHeaders(sheetId, sheetName);
        } else {
          sheetId = existingSheets.data.files[0].id;
        }

        sheetIds[sheetName] = sheetId;
      } catch (error) {
        console.error(`Error creating sheet ${sheetName}:`, error);
        throw error;
      }
    }

    return sheetIds;
  }

  private async initializeSheetHeaders(sheetId: string, sheetName: string) {
    const headers = this.getSheetHeaders(sheetName);
    
    await this.sheets.spreadsheets.values.update({
      spreadsheetId: sheetId,
      range: 'A1:Z1',
      valueInputOption: 'RAW',
      resource: {
        values: [headers],
      },
    });
  }

  private getSheetHeaders(sheetName: string): string[] {
    const headerMap: Record<string, string[]> = {
      'Financial_Accounts': [
        'ID', 'Account Name', 'Account Type', 'Account Number', 
        'Routing Number', 'Bank Name', 'Contact Info', 'Balance', 
        'Interest Rate', 'Document IDs', 'Notes', 'Last Updated'
      ],
      'Insurance_Policies': [
        'ID', 'Policy Type', 'Policy Number', 'Provider', 'Coverage Amount',
        'Deductible', 'Premium Amount', 'Renewal Date', 'Agent Name',
        'Agent Contact', 'Document IDs', 'Notes', 'Last Updated'
      ],
      'Legal_Documents': [
        'ID', 'Document Type', 'Title', 'Parties', 'Effective Date',
        'Expiration Date', 'Key Terms', 'Document IDs', 'Notes', 'Last Updated'
      ],
      'Personal_ID': [
        'ID', 'ID Type', 'ID Number', 'Issuing Authority', 'Issue Date',
        'Expiration Date', 'Holder Name', 'Document IDs', 'Notes', 'Last Updated'
      ],
      'Medical_Info': [
        'ID', 'Category', 'Name', 'Contact Info', 'Details',
        'Insurance Info', 'Document IDs', 'Notes', 'Last Updated'
      ],
      'Property_Assets': [
        'ID', 'Property Type', 'Name', 'Address', 'Purchase Date',
        'Purchase Price', 'Current Value', 'Mortgage Info', 'Insurance Policy ID',
        'Document IDs', 'Notes', 'Last Updated'
      ],
      'Users_Permissions': [
        'ID', 'User Email', 'Role', 'Financial View', 'Financial Edit',
        'Insurance View', 'Insurance Edit', 'Legal View', 'Legal Edit',
        'Medical View', 'Medical Edit', 'Personal ID View', 'Personal ID Edit',
        'Property View', 'Property Edit', 'Temporary Access', 'Access Expiration', 'Last Updated'
      ],
      'Audit_Log': [
        'ID', 'User Email', 'Action', 'Resource Type', 'Resource ID',
        'Timestamp', 'IP Address', 'Details'
      ],
      'Document_Registry': [
        'ID', 'File Name', 'File Type', 'Category', 'File Size',
        'Upload Date', 'Google Drive File ID', 'Description', 'Tags'
      ],
      'Reminders_Alerts': [
        'ID', 'Title', 'Description', 'Category', 'Target Date',
        'Reminder Days', 'Is Active', 'Related Item ID', 'Related Item Type', 'Created Date'
      ],
      'System_Config': [
        'Key', 'Value', 'Description', 'Last Updated'
      ],
    };

    return headerMap[sheetName] || [];
  }

  // Document upload and management
  async uploadDocument(file: Buffer, fileName: string, category: string, folderId: string): Promise<string> {
    const categoryFolders: Record<string, string> = {
      'financial': 'Financial',
      'insurance': 'Insurance',
      'legal': 'Legal',
      'medical': 'Medical',
      'personal_id': 'Personal_ID',
      'property': 'Property',
    };

    const targetFolder = categoryFolders[category] || 'Financial';
    
    // Get category folder ID
    const categoryFolderQuery = await this.drive.files.list({
      q: `name='${targetFolder}' and parents in '${folderId}' and mimeType='application/vnd.google-apps.folder'`,
    });

    const categoryFolderId = categoryFolderQuery.data.files[0]?.id;
    if (!categoryFolderId) {
      throw new Error(`Category folder ${targetFolder} not found`);
    }

    // Upload file
    const fileMetadata = {
      name: fileName,
      parents: [categoryFolderId],
    };

    const media = {
      mimeType: 'application/octet-stream',
      body: file,
    };

    const uploadedFile = await this.drive.files.create({
      resource: fileMetadata,
      media: media,
    });

    return uploadedFile.data.id;
  }

  // Sheets data operations
  async appendSheetData(sheetId: string, data: any[]): Promise<void> {
    await this.sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: 'A:Z',
      valueInputOption: 'RAW',
      resource: {
        values: [data],
      },
    });
  }

  async getSheetData(sheetId: string, range: string = 'A:Z'): Promise<any[][]> {
    const response = await this.sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range: range,
    });

    return response.data.values || [];
  }

  async updateSheetData(sheetId: string, range: string, data: any[][]): Promise<void> {
    await this.sheets.spreadsheets.values.update({
      spreadsheetId: sheetId,
      range: range,
      valueInputOption: 'RAW',
      resource: {
        values: data,
      },
    });
  }

  // Permission management
  async shareDocument(fileId: string, email: string, role: 'reader' | 'writer' | 'owner'): Promise<void> {
    await this.drive.permissions.create({
      fileId: fileId,
      resource: {
        role: role,
        type: 'user',
        emailAddress: email,
      },
    });
  }

  // Search functionality
  async searchDocuments(query: string, folderId: string): Promise<any[]> {
    const searchResults = await this.drive.files.list({
      q: `'${folderId}' in parents and fullText contains '${query}'`,
      fields: 'files(id,name,mimeType,modifiedTime,size)',
    });

    return searchResults.data.files || [];
  }

  // OAuth flow methods
  getAuthUrl(): string {
    const scopes = [
      'https://www.googleapis.com/auth/drive',
      'https://www.googleapis.com/auth/spreadsheets',
      'https://www.googleapis.com/auth/documents',
      'https://www.googleapis.com/auth/gmail.send',
    ];

    return this.auth.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
    });
  }

  async getTokens(code: string): Promise<any> {
    const { tokens } = await this.auth.getToken(code);
    return tokens;
  }
}