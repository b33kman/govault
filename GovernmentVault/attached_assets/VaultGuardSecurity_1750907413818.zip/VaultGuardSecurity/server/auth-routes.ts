import express from 'express';
import { GoogleWorkspaceService } from './google-services';

export function createAuthRoutes(googleService: GoogleWorkspaceService) {
  const router = express.Router();

  // Initiate Google OAuth flow
  router.get('/auth/google', (req, res) => {
    const authUrl = googleService.getAuthUrl();
    res.redirect(authUrl);
  });

  // Handle OAuth callback
  router.get('/auth/google/callback', async (req, res) => {
    try {
      const { code } = req.query;
      
      if (!code || typeof code !== 'string') {
        return res.status(400).json({ error: 'Authorization code required' });
      }

      const tokens = await googleService.getTokens(code);
      googleService.setCredentials(tokens);

      // Store tokens in session (in production, use secure session storage)
      req.session = req.session || {};
      req.session.googleTokens = tokens;

      // Redirect to dashboard
      res.redirect('/dashboard?auth=success');
    } catch (error) {
      console.error('OAuth callback error:', error);
      res.redirect('/login?error=auth_failed');
    }
  });

  // Check authentication status
  router.get('/auth/status', (req, res) => {
    const hasTokens = req.session?.googleTokens != null;
    res.json({ authenticated: hasTokens });
  });

  // Logout
  router.post('/auth/logout', (req, res) => {
    if (req.session) {
      req.session.googleTokens = null;
    }
    res.json({ success: true });
  });

  // Initialize Google Workspace structure
  router.post('/auth/initialize', async (req, res) => {
    try {
      if (!req.session?.googleTokens) {
        return res.status(401).json({ error: 'Not authenticated' });
      }

      googleService.setCredentials(req.session.googleTokens);
      
      // Initialize folder structure and sheets
      const folderId = await googleService.initializeFolderStructure();
      const sheetIds = await googleService.initializeDataSheets(folderId);

      res.json({ 
        success: true, 
        folderId,
        sheetIds
      });
    } catch (error) {
      console.error('Initialization error:', error);
      res.status(500).json({ error: 'Failed to initialize Google Workspace' });
    }
  });

  return router;
}

// Middleware to ensure authentication
export function requireAuth(req: any, res: any, next: any) {
  if (!req.session?.googleTokens) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  next();
}