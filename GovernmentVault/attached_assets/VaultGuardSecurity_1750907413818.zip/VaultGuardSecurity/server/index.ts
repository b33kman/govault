import express from 'express';
import path from 'path';
import { createRoutes } from './routes';
import { createAuthRoutes, requireAuth } from './auth-routes';
import { GoogleWorkspaceService } from './google-services';
import { GoogleSheetsStorage } from './google-storage';
import { MemStorage } from './storage';

const app = express();
const PORT = parseInt(process.env.PORT || '3000');

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../client/dist')));

// CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Simple session storage (in production, use Redis or similar)
declare global {
  namespace Express {
    interface Request {
      session?: any;
    }
  }
}

app.use((req, res, next) => {
  if (!req.session) {
    req.session = {};
  }
  next();
});

// Initialize services
const googleService = new GoogleWorkspaceService();
const storage = process.env.USE_GOOGLE_SHEETS === 'true' 
  ? new GoogleSheetsStorage(googleService)
  : new MemStorage();

// Routes
app.use('/', createAuthRoutes(googleService));
app.use('/', createRoutes(storage));

// Protected API routes (require authentication when using Google Sheets)
if (process.env.USE_GOOGLE_SHEETS === 'true') {
  app.use('/api/*', requireAuth);
}

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/dist/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`GoVAULT server running on http://0.0.0.0:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`Storage: ${process.env.USE_GOOGLE_SHEETS === 'true' ? 'Google Sheets' : 'Memory'}`);
});

export default app;