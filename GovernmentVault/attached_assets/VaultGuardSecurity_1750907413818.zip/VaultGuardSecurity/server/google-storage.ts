import { GoogleWorkspaceService } from './google-services';
import { IStorage } from './storage';
import type {
  FinancialAccount,
  InsertFinancialAccount,
  InsurancePolicy,
  InsertInsurancePolicy,
  LegalDocument,
  InsertLegalDocument,
  PersonalId,
  InsertPersonalId,
  MedicalInfo,
  InsertMedicalInfo,
  PropertyAsset,
  InsertPropertyAsset,
  Document,
  InsertDocument,
  UserPermission,
  InsertUserPermission,
  Reminder,
  InsertReminder,
} from '../shared/schema';

export class GoogleSheetsStorage implements IStorage {
  private googleService: GoogleWorkspaceService;
  private sheetIds: Record<string, string> = {};
  private initialized = false;

  constructor(googleService: GoogleWorkspaceService) {
    this.googleService = googleService;
  }

  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      const folderId = await this.googleService.initializeFolderStructure();
      this.sheetIds = await this.googleService.initializeDataSheets(folderId);
      this.initialized = true;
    } catch (error) {
      console.error('Failed to initialize Google Sheets storage:', error);
      throw error;
    }
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private async ensureInitialized(): Promise<void> {
    if (!this.initialized) {
      await this.initialize();
    }
  }

  // Financial Accounts
  async createFinancialAccount(data: InsertFinancialAccount): Promise<FinancialAccount> {
    await this.ensureInitialized();
    
    const account: FinancialAccount = {
      id: this.generateId(),
      ...data,
      lastUpdated: new Date(),
    };

    const rowData = [
      account.id,
      account.accountName,
      account.accountType,
      account.accountNumber,
      account.routingNumber || '',
      account.bankName,
      account.contactInfo || '',
      account.balance?.toString() || '',
      account.interestRate?.toString() || '',
      account.documentIds.join(','),
      account.notes || '',
      account.lastUpdated.toISOString(),
    ];

    await this.googleService.appendSheetData(this.sheetIds.Financial_Accounts, rowData);
    return account;
  }

  async getFinancialAccounts(): Promise<FinancialAccount[]> {
    await this.ensureInitialized();
    
    const data = await this.googleService.getSheetData(this.sheetIds.Financial_Accounts);
    if (data.length <= 1) return []; // Skip header row

    return data.slice(1).map(row => ({
      id: row[0] || '',
      accountName: row[1] || '',
      accountType: row[2] as any,
      accountNumber: row[3] || '',
      routingNumber: row[4] || undefined,
      bankName: row[5] || '',
      contactInfo: row[6] || undefined,
      balance: row[7] ? parseFloat(row[7]) : undefined,
      interestRate: row[8] ? parseFloat(row[8]) : undefined,
      documentIds: row[9] ? row[9].split(',').filter(Boolean) : [],
      notes: row[10] || undefined,
      lastUpdated: new Date(row[11] || Date.now()),
    }));
  }

  async getFinancialAccountById(id: string): Promise<FinancialAccount | null> {
    const accounts = await this.getFinancialAccounts();
    return accounts.find(account => account.id === id) || null;
  }

  async updateFinancialAccount(id: string, data: Partial<InsertFinancialAccount>): Promise<FinancialAccount> {
    const existing = await this.getFinancialAccountById(id);
    if (!existing) {
      throw new Error('Financial account not found');
    }

    const updated: FinancialAccount = {
      ...existing,
      ...data,
      lastUpdated: new Date(),
    };

    // Update in Google Sheets - find row and update
    const allData = await this.googleService.getSheetData(this.sheetIds.Financial_Accounts);
    const rowIndex = allData.findIndex((row, index) => index > 0 && row[0] === id);
    
    if (rowIndex > 0) {
      const rowData = [
        updated.id,
        updated.accountName,
        updated.accountType,
        updated.accountNumber,
        updated.routingNumber || '',
        updated.bankName,
        updated.contactInfo || '',
        updated.balance?.toString() || '',
        updated.interestRate?.toString() || '',
        updated.documentIds.join(','),
        updated.notes || '',
        updated.lastUpdated.toISOString(),
      ];

      await this.googleService.updateSheetData(
        this.sheetIds.Financial_Accounts,
        `A${rowIndex + 1}:L${rowIndex + 1}`,
        [rowData]
      );
    }

    return updated;
  }

  async deleteFinancialAccount(id: string): Promise<void> {
    // For simplicity, we'll mark as deleted by clearing the row
    // In a production system, you might want to move to a "deleted" sheet
    const allData = await this.googleService.getSheetData(this.sheetIds.Financial_Accounts);
    const rowIndex = allData.findIndex((row, index) => index > 0 && row[0] === id);
    
    if (rowIndex > 0) {
      const emptyRow = new Array(12).fill('');
      await this.googleService.updateSheetData(
        this.sheetIds.Financial_Accounts,
        `A${rowIndex + 1}:L${rowIndex + 1}`,
        [emptyRow]
      );
    }
  }

  // Insurance Policies
  async createInsurancePolicy(data: InsertInsurancePolicy): Promise<InsurancePolicy> {
    await this.ensureInitialized();
    
    const policy: InsurancePolicy = {
      id: this.generateId(),
      ...data,
      lastUpdated: new Date(),
    };

    const rowData = [
      policy.id,
      policy.policyType,
      policy.policyNumber,
      policy.provider,
      policy.coverageAmount.toString(),
      policy.deductible?.toString() || '',
      policy.premiumAmount.toString(),
      policy.renewalDate.toISOString(),
      policy.agentName || '',
      policy.agentContact || '',
      policy.documentIds.join(','),
      policy.notes || '',
      policy.lastUpdated.toISOString(),
    ];

    await this.googleService.appendSheetData(this.sheetIds.Insurance_Policies, rowData);
    return policy;
  }

  async getInsurancePolicies(): Promise<InsurancePolicy[]> {
    await this.ensureInitialized();
    
    const data = await this.googleService.getSheetData(this.sheetIds.Insurance_Policies);
    if (data.length <= 1) return [];

    return data.slice(1).map(row => ({
      id: row[0] || '',
      policyType: row[1] as any,
      policyNumber: row[2] || '',
      provider: row[3] || '',
      coverageAmount: parseFloat(row[4] || '0'),
      deductible: row[5] ? parseFloat(row[5]) : undefined,
      premiumAmount: parseFloat(row[6] || '0'),
      renewalDate: new Date(row[7] || Date.now()),
      agentName: row[8] || undefined,
      agentContact: row[9] || undefined,
      documentIds: row[10] ? row[10].split(',').filter(Boolean) : [],
      notes: row[11] || undefined,
      lastUpdated: new Date(row[12] || Date.now()),
    }));
  }

  async getInsurancePolicyById(id: string): Promise<InsurancePolicy | null> {
    const policies = await this.getInsurancePolicies();
    return policies.find(policy => policy.id === id) || null;
  }

  async updateInsurancePolicy(id: string, data: Partial<InsertInsurancePolicy>): Promise<InsurancePolicy> {
    const existing = await this.getInsurancePolicyById(id);
    if (!existing) {
      throw new Error('Insurance policy not found');
    }

    const updated: InsurancePolicy = {
      ...existing,
      ...data,
      lastUpdated: new Date(),
    };

    const allData = await this.googleService.getSheetData(this.sheetIds.Insurance_Policies);
    const rowIndex = allData.findIndex((row, index) => index > 0 && row[0] === id);
    
    if (rowIndex > 0) {
      const rowData = [
        updated.id,
        updated.policyType,
        updated.policyNumber,
        updated.provider,
        updated.coverageAmount.toString(),
        updated.deductible?.toString() || '',
        updated.premiumAmount.toString(),
        updated.renewalDate.toISOString(),
        updated.agentName || '',
        updated.agentContact || '',
        updated.documentIds.join(','),
        updated.notes || '',
        updated.lastUpdated.toISOString(),
      ];

      await this.googleService.updateSheetData(
        this.sheetIds.Insurance_Policies,
        `A${rowIndex + 1}:M${rowIndex + 1}`,
        [rowData]
      );
    }

    return updated;
  }

  async deleteInsurancePolicy(id: string): Promise<void> {
    const allData = await this.googleService.getSheetData(this.sheetIds.Insurance_Policies);
    const rowIndex = allData.findIndex((row, index) => index > 0 && row[0] === id);
    
    if (rowIndex > 0) {
      const emptyRow = new Array(13).fill('');
      await this.googleService.updateSheetData(
        this.sheetIds.Insurance_Policies,
        `A${rowIndex + 1}:M${rowIndex + 1}`,
        [emptyRow]
      );
    }
  }

  // Placeholder implementations for other entity types
  // These would follow the same pattern as Financial Accounts and Insurance Policies

  async createLegalDocument(data: InsertLegalDocument): Promise<LegalDocument> {
    // Implementation similar to createFinancialAccount
    throw new Error('Not implemented yet');
  }

  async getLegalDocuments(): Promise<LegalDocument[]> {
    return [];
  }

  async getLegalDocumentById(id: string): Promise<LegalDocument | null> {
    return null;
  }

  async updateLegalDocument(id: string, data: Partial<InsertLegalDocument>): Promise<LegalDocument> {
    throw new Error('Not implemented yet');
  }

  async deleteLegalDocument(id: string): Promise<void> {
    // Implementation similar to deleteFinancialAccount
  }

  async createPersonalId(data: InsertPersonalId): Promise<PersonalId> {
    throw new Error('Not implemented yet');
  }

  async getPersonalIds(): Promise<PersonalId[]> {
    return [];
  }

  async getPersonalIdById(id: string): Promise<PersonalId | null> {
    return null;
  }

  async updatePersonalId(id: string, data: Partial<InsertPersonalId>): Promise<PersonalId> {
    throw new Error('Not implemented yet');
  }

  async deletePersonalId(id: string): Promise<void> {
    // Implementation
  }

  async createMedicalInfo(data: InsertMedicalInfo): Promise<MedicalInfo> {
    throw new Error('Not implemented yet');
  }

  async getMedicalInfo(): Promise<MedicalInfo[]> {
    return [];
  }

  async getMedicalInfoById(id: string): Promise<MedicalInfo | null> {
    return null;
  }

  async updateMedicalInfo(id: string, data: Partial<InsertMedicalInfo>): Promise<MedicalInfo> {
    throw new Error('Not implemented yet');
  }

  async deleteMedicalInfo(id: string): Promise<void> {
    // Implementation
  }

  async createPropertyAsset(data: InsertPropertyAsset): Promise<PropertyAsset> {
    throw new Error('Not implemented yet');
  }

  async getPropertyAssets(): Promise<PropertyAsset[]> {
    return [];
  }

  async getPropertyAssetById(id: string): Promise<PropertyAsset | null> {
    return null;
  }

  async updatePropertyAsset(id: string, data: Partial<InsertPropertyAsset>): Promise<PropertyAsset> {
    throw new Error('Not implemented yet');
  }

  async deletePropertyAsset(id: string): Promise<void> {
    // Implementation
  }

  async createDocument(data: InsertDocument): Promise<Document> {
    throw new Error('Not implemented yet');
  }

  async getDocuments(): Promise<Document[]> {
    return [];
  }

  async getDocumentById(id: string): Promise<Document | null> {
    return null;
  }

  async getDocumentsByCategory(category: string): Promise<Document[]> {
    return [];
  }

  async updateDocument(id: string, data: Partial<InsertDocument>): Promise<Document> {
    throw new Error('Not implemented yet');
  }

  async deleteDocument(id: string): Promise<void> {
    // Implementation
  }

  async createUserPermission(data: InsertUserPermission): Promise<UserPermission> {
    throw new Error('Not implemented yet');
  }

  async getUserPermissions(): Promise<UserPermission[]> {
    return [];
  }

  async getUserPermissionById(id: string): Promise<UserPermission | null> {
    return null;
  }

  async getUserPermissionByEmail(email: string): Promise<UserPermission | null> {
    return null;
  }

  async updateUserPermission(id: string, data: Partial<InsertUserPermission>): Promise<UserPermission> {
    throw new Error('Not implemented yet');
  }

  async deleteUserPermission(id: string): Promise<void> {
    // Implementation
  }

  async createReminder(data: InsertReminder): Promise<Reminder> {
    throw new Error('Not implemented yet');
  }

  async getReminders(): Promise<Reminder[]> {
    return [];
  }

  async getReminderById(id: string): Promise<Reminder | null> {
    return null;
  }

  async getActiveReminders(): Promise<Reminder[]> {
    return [];
  }

  async updateReminder(id: string, data: Partial<InsertReminder>): Promise<Reminder> {
    throw new Error('Not implemented yet');
  }

  async deleteReminder(id: string): Promise<void> {
    // Implementation
  }
}