import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/Button';
import { 
  Home,
  DollarSign,
  Shield,
  FileText,
  IdCard,
  Heart,
  Building,
  Settings,
  User,
  Menu,
  X,
  Search,
  Bell,
  Plus
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface LayoutProps {
  children: React.ReactNode;
}

const navigation = [
  { name: 'Dashboard', href: '/', icon: Home },
  { name: 'Financial', href: '/financial', icon: DollarSign },
  { name: 'Insurance', href: '/insurance', icon: Shield },
  { name: 'Legal', href: '/legal', icon: FileText },
  { name: 'Personal IDs', href: '/personal-ids', icon: IdCard },
  { name: 'Medical', href: '/medical', icon: Heart },
  { name: 'Property', href: '/property', icon: Building },
];

export function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar for mobile */}
      <div className={cn(
        "fixed inset-0 z-50 lg:hidden",
        sidebarOpen ? "block" : "hidden"
      )}>
        <div className="fixed inset-0 bg-black/20" onClick={() => setSidebarOpen(false)} />
        <div className="fixed left-0 top-0 h-full w-64 bg-card border-r">
          <div className="flex h-full flex-col">
            <div className="flex h-16 items-center justify-between px-4 border-b">
              <Link href="/">
                <div className="flex items-center space-x-2">
                  <div className="h-8 w-8 govault-gradient rounded-lg flex items-center justify-center">
                    <Home className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-xl font-bold">GoVAULT</span>
                </div>
              </Link>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <nav className="flex-1 px-4 py-4">
              <div className="sidebar-nav">
                {navigation.map((item) => (
                  <Link key={item.name} href={item.href}>
                    <a className={cn(
                      "sidebar-nav-item",
                      location === item.href && "active"
                    )}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </a>
                  </Link>
                ))}
              </div>
            </nav>
          </div>
        </div>
      </div>

      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:z-40 lg:w-64 lg:flex lg:flex-col">
        <div className="flex flex-col h-full bg-card border-r">
          <div className="flex h-16 items-center px-4 border-b">
            <Link href="/">
              <div className="flex items-center space-x-2">
                <div className="h-8 w-8 govault-gradient rounded-lg flex items-center justify-center">
                  <Home className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-bold">GoVAULT</span>
              </div>
            </Link>
          </div>
          <nav className="flex-1 px-4 py-4">
            <div className="sidebar-nav">
              {navigation.map((item) => (
                <Link key={item.name} href={item.href}>
                  <a className={cn(
                    "flex items-center space-x-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground",
                    location === item.href && "bg-accent text-accent-foreground"
                  )}>
                    <item.icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </a>
                </Link>
              ))}
            </div>
          </nav>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top bar */}
        <div className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
          <div className="flex h-16 items-center justify-between px-4">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-4 w-4" />
              </Button>
              
              {/* Search */}
              <div className="hidden md:flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <input
                    placeholder="Search household information..."
                    className="pl-8 pr-3 py-2 w-64 text-sm rounded-md border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-4 w-4" />
                <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full"></span>
              </Button>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
              <Button variant="ghost" size="icon">
                <User className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Page content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
}