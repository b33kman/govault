import { QueryClientProvider } from '@tanstack/react-query';
import { Route, Switch } from 'wouter';
import { Layout } from '@/components/Layout';
import { Dashboard } from '@/components/Dashboard';
import { FinancialPage } from '@/pages/FinancialPage';
import { InsurancePage } from '@/pages/InsurancePage';
import { queryClient } from '@/lib/queryClient';

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Layout>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/financial" component={FinancialPage} />
          <Route path="/insurance" component={InsurancePage} />
          <Route path="/legal">
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-4">Legal Documents</h2>
              <p className="text-muted-foreground">Coming soon - manage your legal documents and contracts</p>
            </div>
          </Route>
          <Route path="/personal-ids">
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-4">Personal IDs</h2>
              <p className="text-muted-foreground">Coming soon - track passports, licenses, and identification documents</p>
            </div>
          </Route>
          <Route path="/medical">
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-4">Medical Information</h2>
              <p className="text-muted-foreground">Coming soon - manage doctors, prescriptions, and health records</p>
            </div>
          </Route>
          <Route path="/property">
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-4">Property & Assets</h2>
              <p className="text-muted-foreground">Coming soon - track real estate, vehicles, and valuable items</p>
            </div>
          </Route>
          <Route>
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-4">Page Not Found</h2>
              <p className="text-muted-foreground">The page you're looking for doesn't exist.</p>
            </div>
          </Route>
        </Switch>
      </Layout>
    </QueryClientProvider>
  );
}

export default App;