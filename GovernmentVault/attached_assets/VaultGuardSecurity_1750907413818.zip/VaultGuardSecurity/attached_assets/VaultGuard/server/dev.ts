import express from 'express';
import { MemStorage } from './storage';
import { createRoutes } from './routes';

const app = express();
const port = parseInt(process.env.PORT || '3000');

// Middleware
app.use(express.json());

// Initialize storage with sample data
const storage = new MemStorage();

// API routes
app.use(createRoutes(storage));

// Serve static files from client dist
app.use(express.static('client/dist'));

// Handle client-side routing - serve index.html for all non-API routes
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile('index.html', { root: 'client/dist' });
  }
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log(`GoVAULT server running on port ${port}`);
  console.log(`Dashboard: http://localhost:${port}`);
  console.log(`Financial: http://localhost:${port}/financial`);
  console.log(`Insurance: http://localhost:${port}/insurance`);
});